package skylarkConsole;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

@ServerEndpoint("/Server")
public class Server {
	private Session session;
	private static final ConcurrentHashMap<String,Object> connections=new ConcurrentHashMap<String,Object>();
	private static final ConcurrentHashMap<String,Object> servers=new ConcurrentHashMap<String,Object>();
	private static final ConcurrentHashMap<Object,String> servers_rev=new ConcurrentHashMap<Object,String>();
	private static final ConcurrentHashMap<String,Object> clients=new ConcurrentHashMap<String,Object>();
	private static final ConcurrentHashMap<Object,String> clients_rev=new ConcurrentHashMap<Object,String>();
	
	@OnOpen
	public void start(Session T) {
		this.session=T;
		T.setMaxBinaryMessageBufferSize(1*1024*1024);
		T.setMaxTextMessageBufferSize(1*1024*1024);
		connections.put(T.getId(),this);
	}
	
	@OnMessage
	public void HandlePkg(String dat,Session T) throws IOException {
		System.out.println(dat);
		Gson gson = new Gson();
		JsonObject pkg=gson.fromJson(dat,JsonObject.class);
		if(!pkg.has("packageType"))	return;
		if(!pkg.has("deviceId")) {
			String pkgType=fom(pkg.get("packageType").toString());
			if(pkgType.equals("requestNewDevId")) {
				String newid=newDevID();
				T.getBasicRemote().sendText("{\"packageType\":\"setDevId\",\"newDevId\":\""+newid+"\"}");
				System.out.println("Applied for new device address: "+newid);
			}
			return;
		}
		String pkgType=fom(pkg.get("packageType").toString());
		String deviceId=fom(pkg.get("deviceId").toString());
		switch(pkgType) {
			case "login":
				String connectionType=fom(pkg.get("connectionType").toString());
				if(deviceId.equals("")) {
					T.getBasicRemote().sendText("{\"packageType\":\"nullDeviceId\"}");
					break;
				}
				if(connectionType.equals("client")) {
					if(servers.containsKey(deviceId)) {
						clients.put(deviceId, T);
						clients_rev.put(T, deviceId);
						T.getBasicRemote().sendText("{\"packageType\":\"loggedIn\"}");
						System.out.println("Client: "+deviceId+" joined servlet.");
					}else {
						System.out.println("Client: "+deviceId+" was rejected.");
						T.getBasicRemote().sendText("{\"packageType\":\"rejected\",\"message\":\"��ID����Ӧ���豸δ���ߣ��볢������������\"}");
					}
				}
				else if(connectionType.equals("server")) {
					servers.put(deviceId, T);
					servers_rev.put(T, deviceId);
					System.out.println("Server: "+deviceId+" joined servlet.");
				}
			break;
			case "empty":
				
			break;
			default:
				if(servers_rev.containsKey(T)) {
					Session client=(Session) clients.get(deviceId);
					client.getBasicRemote().sendText(dat);
				}else if(clients_rev.containsKey(T)) {
					Session server=(Session) servers.get(deviceId);
					server.getBasicRemote().sendText(dat);
				}
			break;
		}
		/*System.out.println();
		System.out.println();*/
	}
	
	@OnClose
	public void handleDisconnection(Session T) {
		if(servers_rev.containsKey(T)) {
			System.out.println("Server: "+servers_rev.get(T)+" leave servlet.");
			servers.remove(servers_rev.get(T));
			servers_rev.remove(T);
		}else if(clients_rev.containsKey(T)){
			System.out.println("Client: "+clients_rev.get(T)+" leave servlet.");
			clients.remove(clients_rev.get(T));
			clients_rev.remove(T);
		}
	}
	
	private String fom(String T) {if(T.length()<=2) return ""; return T.substring(1,T.length()-1);}
	private String newDevID() {
		String KeyElems="3456789ABCDEFGHJKLMNPQRSTWXY";
		StringBuffer tmp = new StringBuffer();
		for(int i=0;i<4;i++) {
			for(int j=0;j<5;j++) tmp.append(KeyElems.charAt((int)(Math.random()*(KeyElems.length()-1-0)+0)));
			if(i!=3) tmp.append("-");
		}
		return tmp.toString();
	}
}