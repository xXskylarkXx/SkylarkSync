var minWidth_adapt;
function initAdapt(T){
	minWidth_adapt=T;
	var objs=document.getElementsByClassName("adapt"), objN = objs.length;
	for(var i=0 ; i<objN ; i++){
		objs[i].left=parseInt(document.defaultView.getComputedStyle(objs[i]).left);
	}
}
function adapt(){
	var objs=document.getElementsByClassName("adapt"), objN = objs.length;
	var maxX=window.innerWidth, orgLeft;
	var moveX=(maxX-minWidth_adapt)/2;
	if(moveX<0) moveX=0;
	for(var i=0 ; i<objN ; i++){
		orgLeft=objs[i].left;
		objs[i].style.left=(orgLeft+moveX)+'px';
	}
}
window.onresize = function(){adapt();}